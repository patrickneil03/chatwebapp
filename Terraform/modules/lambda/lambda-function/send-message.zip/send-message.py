import os
import json
import boto3
from datetime import datetime
from boto3.dynamodb.conditions import Key

# DynamoDB tables
dynamodb          = boto3.resource("dynamodb")
messages_table    = dynamodb.Table(os.environ["DYNAMODB_MESSAGES_TABLE_NAME"])
connections_table = dynamodb.Table(os.environ["DYNAMODB_TABLE_NAME"])

# WebSocket API Gateway endpoint
WEBSOCKET_API_URL = os.environ["WEBSOCKET_API_URL"]
apigw             = boto3.client(
    "apigatewaymanagementapi",
    endpoint_url=WEBSOCKET_API_URL
)

# GSI name for querying connections by roomId
ROOM_INDEX = "RoomIndex"

def lambda_handler(event, context):
    try:
        # 1) Parse connection and payload
        connection_id = event["requestContext"]["connectionId"]
        body          = json.loads(event.get("body", "{}"))
        action        = body.get("action")
        room_id       = body.get("roomId")
        from_name     = body.get("fromName", connection_id)
        message_text  = body.get("message", "")

        # 2) Validate
        if not action or not room_id:
            return {"statusCode": 400, "body": "Missing action or roomId."}

        # 3) Build the broadcast payload
        if action == "sendMessage":
            if not message_text:
                return {"statusCode": 400, "body": "Missing message text."}
            # Persist the chat message
            timestamp = datetime.utcnow().isoformat()
            messages_table.put_item(Item={
                "roomId":    room_id,
                "timestamp": timestamp,
                "from":      connection_id,
                "fromName":  from_name,
                "message":   message_text
            })
            payload = {
                "action":    "newMessage",
                "fromName":  from_name,
                "message":   message_text,
                "timestamp": timestamp
            }

        elif action == "userJoined":
            # No persistence, just broadcast join
            payload = {
                "action":   "userJoined",
                "fromName": from_name
            }

        elif action in ("typing", "stopTyping", "userLeft"):
            # Broadcast typing, stopTyping, or leave
            payload = {
                "action":   action,
                "fromName": from_name
            }

        else:
            return {
                "statusCode": 400,
                "body":       f"Unsupported action: {action}"
            }

        # 4) Query all connections in this room
        resp = connections_table.query(
            IndexName=ROOM_INDEX,
            KeyConditionExpression=Key("roomId").eq(room_id)
        )

        # 5) Broadcast to each connection
        for item in resp.get("Items", []):
            target_id = item["connectionId"]

            # Don't echo typing/stopTyping/userJoined back to the originator
            if action in ("typing", "stopTyping", "userJoined") and target_id == connection_id:
                continue

            try:
                apigw.post_to_connection(
                    ConnectionId=target_id,
                    Data=json.dumps(payload).encode("utf-8")
                )
            except apigw.exceptions.GoneException:
                # Remove stale connection
                connections_table.delete_item(Key={"connectionId": target_id})
            except Exception as e:
                print(f"Error sending to {target_id}: {e}")

        return {"statusCode": 200, "body": "Action processed."}

    except Exception as e:
        print(f"Fatal error: {e}")
        return {"statusCode": 500, "body": "Internal server error"}
